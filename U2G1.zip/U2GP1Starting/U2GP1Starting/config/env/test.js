// Set the 'test' environment configuration object
module.exports = {
	sessionSecret: 'testSessionSecret'
};