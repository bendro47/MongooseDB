// Set the 'development' environment configuration object
module.exports = {
	db: 'mongodb://localhost/mean-book',
	sessionSecret: 'developmentSessionSecret'
};
